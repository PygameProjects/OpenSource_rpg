#! /usr/bin/python

from idlelib.PyShell import main
main()
