#!/usr/bin/python2.6
print("I'm foo")
