print 'SPAM'
